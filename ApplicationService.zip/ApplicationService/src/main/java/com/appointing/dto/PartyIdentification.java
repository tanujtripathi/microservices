package com.appointing.dto;

public class PartyIdentification {

	ID IDObject;

	// Getter Methods

	public ID getID() {
		return IDObject;
	}

	// Setter Methods

	public void setID(ID IDObject) {
		this.IDObject = IDObject;
	}

}
