package com.appointing.dto;

public class Features {

	AppointmentFeatureSet AppointmentFeatureSetObject;

	// Getter Methods

	public AppointmentFeatureSet getAppointmentFeatureSet() {
		return AppointmentFeatureSetObject;
	}

	// Setter Methods

	public void setAppointmentFeatureSet(AppointmentFeatureSet AppointmentFeatureSetObject) {
		this.AppointmentFeatureSetObject = AppointmentFeatureSetObject;
	}

}
