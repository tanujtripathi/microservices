package com.appointing.dto;

public class ListAvailableappointmentResponse {

}
