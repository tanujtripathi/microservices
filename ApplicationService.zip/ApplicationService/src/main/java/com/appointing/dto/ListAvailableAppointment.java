package com.appointing.dto;

import java.io.Serializable;

import com.appointing.list.dto.ListAvailableAppointmentResponse;

public class ListAvailableAppointment implements Serializable {
	ListAvailableAppointmentResponse listAvailableAppointmentResponse = new ListAvailableAppointmentResponse();

	public ListAvailableAppointment() {
		// TODO Auto-generated constructor stub
	}

	public ListAvailableAppointmentResponse getListAvailableAppointmentResponse() {
		return listAvailableAppointmentResponse;
	}

	public void setListAvailableAppointmentResponse(ListAvailableAppointmentResponse listAvailableAppointmentResponse) {
		this.listAvailableAppointmentResponse = listAvailableAppointmentResponse;
	}

}
