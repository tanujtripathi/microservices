package com.appointing.dto;

public class RequesterParty {

	Party PartyObject;

	// Getter Methods

	public Party getParty() {
		return PartyObject;
	}

	// Setter Methods

	public void setParty(Party PartyObject) {
		this.PartyObject = PartyObject;
	}

}
