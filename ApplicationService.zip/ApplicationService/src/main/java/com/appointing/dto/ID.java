package com.appointing.dto;

public class ID {

	private String _identificationSchemeName;
	private String __text;

	// Getter Methods

	public String get_identificationSchemeName() {
		return _identificationSchemeName;
	}

	public String get__text() {
		return __text;
	}

	// Setter Methods

	public void set_identificationSchemeName(String _identificationSchemeName) {
		this._identificationSchemeName = _identificationSchemeName;
	}

	public void set__text(String __text) {
		this.__text = __text;
	}

}
