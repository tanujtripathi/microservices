package com.appointing.dto;

public class ResponderParty {

	Party PartyObject;

	// Getter Methods

	public Party getParty() {
		return PartyObject;
	}

	// Setter Methods

	public void setParty(Party PartyObject) {
		this.PartyObject = PartyObject;
	}

}
