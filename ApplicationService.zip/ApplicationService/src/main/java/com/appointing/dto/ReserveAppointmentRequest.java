package com.appointing.dto;

public class ReserveAppointmentRequest {

}
