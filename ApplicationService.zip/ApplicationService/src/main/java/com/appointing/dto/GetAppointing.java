package com.appointing.dto;

import com.appointing.get.dto.Appointment;

public class GetAppointing {
Appointment getAppointmentResponse;

public Appointment getGetAppointmentResponse() {
	return getAppointmentResponse;
}

public void setGetAppointmentResponse(Appointment getAppointmentResponse) {
	this.getAppointmentResponse = getAppointmentResponse;
}

public GetAppointing() {
	//super();
	// TODO Auto-generated constructor stub
}
}
