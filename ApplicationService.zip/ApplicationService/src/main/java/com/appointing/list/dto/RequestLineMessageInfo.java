package com.appointing.list.dto;

import java.io.Serializable;

public class RequestLineMessageInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private MessageInfo messageInfo = new MessageInfo();

	public RequestLineMessageInfo() {
	}

	public MessageInfo getMessageInfo() {
		return messageInfo;
	}

	public void setMessageInfo(MessageInfo messageInfo) {
		this.messageInfo = messageInfo;
	}

	@Override
	public String toString() {
		return "RequestLineMessageInfo [messageInfo=" + messageInfo + "]";
	}

}
