package com.appointing.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties()
public class Resturls {
		
	private String validationReserveCallUrl;
	private String validationGetCallUrl;
	private String validationListCallUrl;
	private String getAvailableEngineerInfoUrl;
	private String mQClientCallUrl;
	private String reserveCallUri;
	private String listCallUri;
	private String getCallUri;
	public String getValidationReserveCallUrl() {
		return validationReserveCallUrl;
	}
	public void setValidationReserveCallUrl(String validationReserveCallUrl) {
		this.validationReserveCallUrl = validationReserveCallUrl;
	}
	public String getValidationGetCallUrl() {
		return validationGetCallUrl;
	}
	public void setValidationGetCallUrl(String validationGetCallUrl) {
		this.validationGetCallUrl = validationGetCallUrl;
	}
	public String getValidationListCallUrl() {
		return validationListCallUrl;
	}
	public void setValidationListCallUrl(String validationListCallUrl) {
		this.validationListCallUrl = validationListCallUrl;
	}
	public String getGetAvailableEngineerInfoUrl() {
		return getAvailableEngineerInfoUrl;
	}
	public void setGetAvailableEngineerInfoUrl(String getAvailableEngineerInfoUrl) {
		this.getAvailableEngineerInfoUrl = getAvailableEngineerInfoUrl;
	}
	public String getmQClientCallUrl() {
		return mQClientCallUrl;
	}
	public void setmQClientCallUrl(String mQClientCallUrl) {
		this.mQClientCallUrl = mQClientCallUrl;
	}
	public String getReserveCallUri() {
		return reserveCallUri;
	}
	public void setReserveCallUri(String reserveCallUri) {
		this.reserveCallUri = reserveCallUri;
	}
	public String getListCallUri() {
		return listCallUri;
	}
	public void setListCallUri(String listCallUri) {
		this.listCallUri = listCallUri;
	}
	public String getGetCallUri() {
		return getCallUri;
	}
	public void setGetCallUri(String getCallUri) {
		this.getCallUri = getCallUri;
	}
	
}
