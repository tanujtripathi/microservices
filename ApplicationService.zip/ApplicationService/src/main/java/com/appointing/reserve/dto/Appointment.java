package com.appointing.reserve.dto;

public class Appointment {

	public Appointment() {
		// TODO Auto-generated constructor stub
	}
	 Reference reference =new Reference();
	public Reference getReference() {
		return reference;
	}
	public void setReference(Reference reference) {
		this.reference = reference;
	}

}
