package com.appointing.reserve.dto;

import com.appointing.list.dto.RequestLineMessageInfo;

public class ReserveAppointmentResponse {

	private Appointment appointment;
	private RequestLineMessageInfo requestLineMessageInfo;

	public ReserveAppointmentResponse() {
	}

	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}

	public RequestLineMessageInfo getRequestLineMessageInfo() {
		return requestLineMessageInfo;
	}

	public void setRequestLineMessageInfo(RequestLineMessageInfo requestLineMessageInfo) {
		this.requestLineMessageInfo = requestLineMessageInfo;
	}

	@Override
	public String toString() {
		return "ReserveAppointmentResponse [appointment=" + appointment + ", requestLineMessageInfo="
				+ requestLineMessageInfo + "]";
	}
}
