package com.appointing.service;

import com.appointing.dto.ListAvailableappointmentResponse;
import com.appointing.reserve.dto.ReserveAppointmentResponse;
import com.appointing.get.dto.Appointment;
import com.appointing.list.dto.ListAvailableAppointment;
import com.appointing.list.dto.ListAvailableAppointmentResponse;

public interface AppointingService {
	
	public com.bt.appointment.dto.ListAvailableAppointment reserveAppointing(String AppointmentDate, String AppointmentTimeslot );
	public ListAvailableAppointment listAppointing(String AppointmentDate);
	public com.bt.appointment.dto.GetappointmentDetails getAppointing(String refnum);

}
