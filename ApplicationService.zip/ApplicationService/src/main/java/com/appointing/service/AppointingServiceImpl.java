package com.appointing.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.appointing.configuration.Resturls;
import com.appointing.dto.AppoinitngValidationResponse;
import com.appointing.list.dto.ListAvailableAppointment;
import com.appointing.list.dto.ListAvailableAppointmentResponse;
import com.appointing.list.dto.MessageInfo;
import com.appointing.list.dto.RequestLineMessageInfo;
import com.appointing.reserve.dto.ReserveAppointmentResponse;
import com.bt.appointment.dto.Appointment;
import com.bt.appointment.dto.GetappointmentDetails;
import com.bt.appointment.dto.GetappointmentDetailsResponse;

@Component
public class AppointingServiceImpl implements AppointingService {

	@Autowired
	Resturls restUrls;

	@Value("${validationReserveCallUrl}")
	private String validationReserveCallUrl;

	@Value("${validationGetCallUrl}")
	private String validationGetCallUrl;

	@Value("${validationListCallUrl}")
	private String validationListCallUrl;

	@Value("${getAvailableEngineerInfoUrl}")
	private String getAvailableEngineerInfoUrl;

	@Value("${mQClientCallUrl}")
	private String mQClientCallUrl;

	@Value("${reserveCallUri}")
	private String reserveCallUri;

	@Value("${listCallUri}")
	private String listCallUri;

	@Value("${getCallUri}")
	private String getCallUri;

	private static RestTemplate restTemplate = new RestTemplate();

	public static final String OK = "OK";

	@Override
	public com.bt.appointment.dto.ListAvailableAppointment reserveAppointing(String AppointmentDate,
			String AppointmentTimeslot) {

		// String h = restUrls.getA();
		AppoinitngValidationResponse appoinitngValidationResponse = validationReserveCall(AppointmentDate,
				AppointmentTimeslot);

		if (StringUtils.equalsIgnoreCase(appoinitngValidationResponse.getResponseMessage(), OK)) {

			com.bt.appointment.dto.ListAvailableAppointment reserveAppointmentResponse = ReserveCall(AppointmentDate,
					AppointmentTimeslot);

			String RefNum = getAvailableEngineerInfo(reserveAppointmentResponse.getListAvailableAppointmentResponse()
					.getAppointment().get(0).getApp_refId());

			String isAvailable = getAvailableEngineerInfo(RefNum);
			// String isAvailable = getAvailableEngineerInfo("23232");

			if (StringUtils.equalsIgnoreCase(isAvailable, "yes")) {
				// TODO: rabbit mq
				System.out.println("Engineers are available");

				/*
				 * String PublishClient; PublishClient =
				 * MQClientCall(reserveAppointmentResponse); System.out.println("PublishClient"
				 * + PublishClient);
				 */

			} else {
				// Failed Reserve call
				reserveAppointmentResponse = ReserveCall(AppointmentDate, "FA");
				System.out.println("Engineers are not available");

			}
			return reserveAppointmentResponse;
		} else {

			RequestLineMessageInfo requestLineMessageInfo = new RequestLineMessageInfo();
			MessageInfo messageInfo = new MessageInfo();
			messageInfo.setMessage(appoinitngValidationResponse.getResponseMessage());
			messageInfo.setCompletionCode(appoinitngValidationResponse.getResponseCode());
			messageInfo.setSeverity("Medium");
			requestLineMessageInfo.setMessageInfo(messageInfo);

			com.bt.appointment.dto.ListAvailableAppointment reserveAppointmentResponse = new com.bt.appointment.dto.ListAvailableAppointment();
			// reserveAppointmentResponse.setRequestLineMessageInfo(requestLineMessageInfo);
			reserveAppointmentResponse.getListAvailableAppointmentResponse()
					.setRequestLineMessageInfo(requestLineMessageInfo);
			return reserveAppointmentResponse;
		}

	}

	@Override
	public com.bt.appointment.dto.GetappointmentDetails getAppointing(String refnum) {
		// GetAppointmentDetailsResponse getAppointmentDetailsResponse=new
		// GetAppointmentDetailsResponse();
		com.bt.appointment.dto.GetappointmentDetails getappointmentDetails = new com.bt.appointment.dto.GetappointmentDetails();
		AppoinitngValidationResponse appoinitngValidationResponse = new AppoinitngValidationResponse();
		appoinitngValidationResponse = validationGetCall(refnum);
		if (StringUtils.equalsIgnoreCase(appoinitngValidationResponse.getResponseMessage(), "Ok")) {
			getappointmentDetails = GetCall(refnum);
			return getappointmentDetails;
		} else {
			RequestLineMessageInfo requestLineMessageInfo = new RequestLineMessageInfo();
			MessageInfo messageInfo = new MessageInfo();
			GetappointmentDetailsResponse getappointmentDetailsResponse = new GetappointmentDetailsResponse();
			messageInfo.setMessage(appoinitngValidationResponse.getResponseMessage());
			messageInfo.setCompletionCode(appoinitngValidationResponse.getResponseCode());
			messageInfo.setSeverity("Medium");
			requestLineMessageInfo.setMessageInfo(messageInfo);
			getappointmentDetailsResponse.setRequestLineMessageInfo(requestLineMessageInfo);
			getappointmentDetails.setGetappointmentDetailsResponse(getappointmentDetailsResponse);
			return getappointmentDetails;
		}
	}

	@Override
	public ListAvailableAppointment listAppointing(String AppointmentDate) {
		ListAvailableAppointment listAvailableAppointment = new ListAvailableAppointment();
		AppoinitngValidationResponse appoinitngValidationResponse = new AppoinitngValidationResponse();
		appoinitngValidationResponse = validationListCall(AppointmentDate);
		if (StringUtils.equalsIgnoreCase(appoinitngValidationResponse.getResponseMessage(), "Ok")) {
			// listAvailableAppointment = ListCall(AppointmentDate);
			List<com.bt.appointment.dto.Appointment> appointments = ListCall(AppointmentDate);

			List<com.appointing.list.dto.Appointment> listOfAppointments = listAvailableAppointment
					.getListAvailableAppointmentResponse().getAppointment();


			for (com.bt.appointment.dto.Appointment appointment2 : appointments) {

				com.appointing.list.dto.Appointment appointment = new com.appointing.list.dto.Appointment();
				appointment.setAppointmentDate(appointment2.getDate());
				appointment.setAppointmentTimeslot(appointment2.getAm_pm());
				listOfAppointments.add(appointment);

			}

			return listAvailableAppointment;
		} else {
			RequestLineMessageInfo requestLineMessageInfo = new RequestLineMessageInfo();
			MessageInfo messageInfo = new MessageInfo();
			ListAvailableAppointmentResponse listAvailableAppointmentResponse = new ListAvailableAppointmentResponse();
			messageInfo.setMessage(appoinitngValidationResponse.getResponseMessage());
			messageInfo.setCompletionCode(appoinitngValidationResponse.getResponseCode());
			messageInfo.setSeverity("Medium");
			requestLineMessageInfo.setMessageInfo(messageInfo);
			listAvailableAppointmentResponse.setRequestLineMessageInfo(requestLineMessageInfo);
			listAvailableAppointment.setListAvailableAppointmentResponse(listAvailableAppointmentResponse);
			return listAvailableAppointment;
		}
	}

	public AppoinitngValidationResponse validationGetCall(String refNum) {

		// String url =
		// "https://appointing-validation-service.cfapps.io/validation/getAppointing";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(validationGetCallUrl).queryParam("refNum",
				refNum);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);

		return responseEntity.getBody();
	}

	public AppoinitngValidationResponse validationListCall(String startDate) {

		// String url =
		// "https://appointing-validation-service.cfapps.io/validation/listAppointment";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(validationListCallUrl)
				.queryParam("startDate", startDate);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);

		return responseEntity.getBody();
	}

	public AppoinitngValidationResponse validationReserveCall(String AppointmentDate, String AppointmentTimeslot) {

		// String url =
		// "http://appointing-validation-service.cfapps.io/validation/reserveAppointing";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(validationReserveCallUrl)
				.queryParam("appointmentDate", AppointmentDate).queryParam("appointmentTimeslot", AppointmentTimeslot);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);

		return responseEntity.getBody();
	}

	public String getAvailableEngineerInfo(String referenceId) {

		// String engineersUrl = "https://engineerapp.cfapps.io/getAvailableEngineers/"
		// + referenceId;

		ResponseEntity<String> result = restTemplate.getForEntity(getAvailableEngineerInfoUrl + referenceId,
				String.class);

		return result.getBody();
	}

	public String MQClientCall(ReserveAppointmentResponse reserveAppointmentResponse) {

		HttpEntity<ReserveAppointmentResponse> request1 = new HttpEntity<ReserveAppointmentResponse>(
				reserveAppointmentResponse);
		return restTemplate.exchange(mQClientCallUrl, HttpMethod.POST, request1, String.class).getBody();
	}

	public com.bt.appointment.dto.ListAvailableAppointment ReserveCall(String AppointmentDate,
			String AppointmentTimeslot) {

//		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(reserveCallUri)
//				.queryParam("date", AppointmentDate).queryParam("slot", AppointmentTimeslot);
		ResponseEntity<com.bt.appointment.dto.ListAvailableAppointment> responseEntity = restTemplate.exchange(
				"https://reservemicroservice.cfapps.io/api/reserve", HttpMethod.GET, null, com.bt.appointment.dto.ListAvailableAppointment.class);
		return responseEntity.getBody();
	}

	public List<Appointment> ListCall(String startDate) {

//		// String url = "http://localhost:8080/validation/listAppointment";
//		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(listCallUri).queryParam("startDate",
//				startDate);
		
		ResponseEntity<List<Appointment>> responseEntity = restTemplate.exchange("https://reservemicroservice.cfapps.io/api/list", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Appointment>>(){});

		List<Appointment> listOfAppointments = (List<Appointment>) responseEntity.getBody();
		return listOfAppointments;
	}

	public GetappointmentDetails GetCall(String refNum) {
		// String url = "http://localhost:8305/api/get";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(getCallUri).queryParam("app_refId", refNum);
		ResponseEntity<GetappointmentDetails> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, GetappointmentDetails.class);
		return responseEntity.getBody();
	}
}
