package com.bt.appointment.dto;

import java.io.Serializable;

public class GetappointmentDetails implements Serializable{
	GetappointmentDetailsResponse getappointmentDetailsResponse = new GetappointmentDetailsResponse();
public GetappointmentDetails() {
	// TODO Auto-generated constructor stub
}
public GetappointmentDetailsResponse getGetappointmentDetailsResponse() {
	return getappointmentDetailsResponse;
}
public void setGetappointmentDetailsResponse(
		GetappointmentDetailsResponse getappointmentDetailsResponse) {
	this.getappointmentDetailsResponse = getappointmentDetailsResponse;
}
	

}
