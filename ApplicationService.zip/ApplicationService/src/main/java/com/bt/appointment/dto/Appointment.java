package com.bt.appointment.dto;


public class Appointment {
	
	private String app_refId;
	
	private String date;
	
	private String am_pm;
	
	private boolean status;

	public String getApp_refId() {
		return app_refId;
	}

	public void setApp_refId(String app_refId) {
		this.app_refId = app_refId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getAm_pm() {
		return am_pm;
	}

	public void setAm_pm(String am_pm) {
		this.am_pm = am_pm;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	
	
	
}
