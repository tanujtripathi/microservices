package com.bt.appointment.dto;

import java.io.Serializable;
import java.util.ArrayList;


public class GetappointmentDetailsResponse implements Serializable {
	
	 public GetappointmentDetailsResponse() {
		super();
		}
	 com.appointing.list.dto.Appointment  Appointment =  new com.appointing.list.dto.Appointment();
	 com.appointing.list.dto.RequestLineMessageInfo requestLineMessageInfo = new com.appointing.list.dto.RequestLineMessageInfo();
	public com.appointing.list.dto.Appointment getAppointment() {
		return Appointment;
	}
	public void setAppointment(com.appointing.list.dto.Appointment appointment) {
		Appointment = appointment;
	}
	public com.appointing.list.dto.RequestLineMessageInfo getRequestLineMessageInfo() {
		return requestLineMessageInfo;
	}
	public void setRequestLineMessageInfo(com.appointing.list.dto.RequestLineMessageInfo requestLineMessageInfo) {
		this.requestLineMessageInfo = requestLineMessageInfo;
	}
	
	
	 

}
