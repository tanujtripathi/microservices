package com.appointing.dto;

public class Appointment {

	Reference ReferenceObject;

	// Getter Methods

	public Reference getReference() {
		return ReferenceObject;
	}

	// Setter Methods

	public void setReference(Reference ReferenceObject) {
		this.ReferenceObject = ReferenceObject;
	}

}
