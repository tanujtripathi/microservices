package com.appointing.dto;

public class Validation {

	public Validation() {
		// TODO Auto-generated constructor stub
	}

}
