package com.appointing.dto;

public class QueryLine {

	QueryLineItem QueryLineItemObject;

	// Getter Methods

	public QueryLineItem getQueryLineItem() {
		return QueryLineItemObject;
	}

	// Setter Methods

	public void setQueryLineItem(QueryLineItem QueryLineItemObject) {
		this.QueryLineItemObject = QueryLineItemObject;
	}

}
