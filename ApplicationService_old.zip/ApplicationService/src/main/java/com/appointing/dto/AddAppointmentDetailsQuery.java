package com.appointing.dto;

public class AddAppointmentDetailsQuery {
	Query QueryObject;

	// Getter Methods

	public Query getQuery() {
		return QueryObject;
	}

	// Setter Methods

	public void setQuery(Query QueryObject) {
		this.QueryObject = QueryObject;
	}
}
