package com.appointing.dto;

public class Party {

	PartyIdentification PartyIdentificationObject;

	// Getter Methods

	public PartyIdentification getPartyIdentification() {
		return PartyIdentificationObject;
	}

	// Setter Methods

	public void setPartyIdentification(PartyIdentification PartyIdentificationObject) {
		this.PartyIdentificationObject = PartyIdentificationObject;
	}

}
