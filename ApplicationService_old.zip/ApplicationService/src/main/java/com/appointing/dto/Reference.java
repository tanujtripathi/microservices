package com.appointing.dto;

public class Reference {

	private String RefNum;

	// Getter Methods

	public String getRefNum() {
		return RefNum;
	}

	// Setter Methods

	public void setRefNum(String RefNum) {
		this.RefNum = RefNum;
	}

}
