package com.appointing.dto;

public class GenericCPWSHubService {
	AddAppointmentDetailsQuery AddAppointmentDetailsQueryObject;

	// Getter Methods

	public AddAppointmentDetailsQuery getAddAppointmentDetailsQuery() {
		return AddAppointmentDetailsQueryObject;
	}

	// Setter Methods

	public void setAddAppointmentDetailsQuery(AddAppointmentDetailsQuery AddAppointmentDetailsQueryObject) {
		this.AddAppointmentDetailsQueryObject = AddAppointmentDetailsQueryObject;
	}
}
