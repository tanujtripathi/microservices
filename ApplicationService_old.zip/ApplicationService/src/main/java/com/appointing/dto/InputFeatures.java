package com.appointing.dto;

public class InputFeatures {

	Appointment AppointmentObject;

	// Getter Methods

	public Appointment getAppointment() {
		return AppointmentObject;
	}

	// Setter Methods

	public void setAppointment(Appointment AppointmentObject) {
		this.AppointmentObject = AppointmentObject;
	}

}
