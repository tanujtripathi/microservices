package com.appointing.dto;

public class ListAvailableappointmentRequest {

}
