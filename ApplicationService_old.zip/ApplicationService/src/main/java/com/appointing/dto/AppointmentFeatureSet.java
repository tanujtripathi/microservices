package com.appointing.dto;

public class AppointmentFeatureSet {

	InputFeatures InputFeaturesObject;

	// Getter Methods

	public InputFeatures getInputFeatures() {
		return InputFeaturesObject;
	}

	// Setter Methods

	public void setInputFeatures(InputFeatures InputFeaturesObject) {
		this.InputFeaturesObject = InputFeaturesObject;
	}

}
