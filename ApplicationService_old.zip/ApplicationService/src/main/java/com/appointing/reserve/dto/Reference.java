package com.appointing.reserve.dto;

public class Reference {

	public Reference() {
		// TODO Auto-generated constructor stub
	}
   String RefNum;
public String getRefNum() {
	return RefNum;
}
public void setRefNum(String refNum) {
	RefNum = refNum;
}
}
