package com.appointing.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.appointing.dto.AppoinitngValidationResponse;
import com.appointing.list.dto.ListAvailableAppointment;
//import com.appointing.get.dto.GetAppointmentDetailsResponse;
import com.appointing.list.dto.ListAvailableAppointmentResponse;
import com.appointing.list.dto.MessageInfo;
import com.appointing.list.dto.RequestLineMessageInfo;
//import com.appointing.dto.ListAvailableappointmentResponse;
import com.appointing.reserve.dto.ReserveAppointmentResponse;
import com.bt.appointment.dto.GetappointmentDetailsResponse;

@Component
public class AppointingServiceImpl implements AppointingService {

	RestTemplate restTemplate = new RestTemplate();

	@Override
	public ReserveAppointmentResponse reserveAppointing(String AppointmentDate, String AppointmentTimeslot) {

		ReserveAppointmentResponse reserveAppointmentResponse = new ReserveAppointmentResponse();
		AppoinitngValidationResponse appoinitngValidationResponse = new AppoinitngValidationResponse();
		appoinitngValidationResponse = validationReserveCall(AppointmentDate, AppointmentTimeslot);

		
			

if (StringUtils.equalsIgnoreCase(appoinitngValidationResponse.getResponseMessage(), "Ok")) {
			

			String isAvailable = getAvailableEngineerInfo("1234");

			if (StringUtils.equalsIgnoreCase(isAvailable, "yes")) {
				// rabbit mq
				// return reserveAppointmentResponse;
				System.out.println("Engineers are available");

			} else {
				// Failed Reserve call
				// return reserveAppointmentResponse;
				System.out.println("Engineers are not available");

			}
			return reserveAppointmentResponse;
		}
		else {
			RequestLineMessageInfo requestLineMessageInfo= new RequestLineMessageInfo();
			MessageInfo  messageInfo= new MessageInfo();
			messageInfo.setMessage(appoinitngValidationResponse.getResponseMessage());
			messageInfo.setCompletionCode(appoinitngValidationResponse.getResponseCode());
			messageInfo.setSeverity("Medium");
			requestLineMessageInfo.setMessageInfo(messageInfo);
			reserveAppointmentResponse.setRequestLineMessageInfo(requestLineMessageInfo);
			return reserveAppointmentResponse;
		}
		
		
	}
	
	@Override
	public  com.bt.appointment.dto.GetappointmentDetails getAppointing(String refnum) {
		//GetAppointmentDetailsResponse getAppointmentDetailsResponse=new GetAppointmentDetailsResponse();
		com.bt.appointment.dto.GetappointmentDetails getappointmentDetails=new com.bt.appointment.dto.GetappointmentDetails();
		AppoinitngValidationResponse appoinitngValidationResponse = new AppoinitngValidationResponse();
		appoinitngValidationResponse = validationGetCall(refnum);
		if (StringUtils.equalsIgnoreCase(appoinitngValidationResponse.getResponseMessage(), "Ok")) {
			return getappointmentDetails;
		}
		else {
			RequestLineMessageInfo requestLineMessageInfo= new RequestLineMessageInfo();
			MessageInfo  messageInfo= new MessageInfo();
			GetappointmentDetailsResponse getappointmentDetailsResponse=new GetappointmentDetailsResponse();
			messageInfo.setMessage(appoinitngValidationResponse.getResponseMessage());
			messageInfo.setCompletionCode(appoinitngValidationResponse.getResponseCode());
			messageInfo.setSeverity("Medium");
			requestLineMessageInfo.setMessageInfo(messageInfo);
			getappointmentDetailsResponse.setRequestLineMessageInfo(requestLineMessageInfo);
			getappointmentDetails.setGetappointmentDetailsResponse(getappointmentDetailsResponse);
			return getappointmentDetails;
		}		
	}
	
			

	@Override
	public  
	    ListAvailableAppointment listAppointing(String AppointmentDate) {
		ListAvailableAppointment listAvailableAppointment = new ListAvailableAppointment();
		AppoinitngValidationResponse appoinitngValidationResponse = new AppoinitngValidationResponse();
		appoinitngValidationResponse =validationListCall(AppointmentDate);
		if (StringUtils.equalsIgnoreCase(appoinitngValidationResponse.getResponseMessage(), "Ok")) {
			return listAvailableAppointment;
		}
		else {
			RequestLineMessageInfo requestLineMessageInfo= new RequestLineMessageInfo();
			MessageInfo  messageInfo= new MessageInfo();
			ListAvailableAppointmentResponse listAvailableAppointmentResponse=new ListAvailableAppointmentResponse();
			messageInfo.setMessage(appoinitngValidationResponse.getResponseMessage());
			messageInfo.setCompletionCode(appoinitngValidationResponse.getResponseCode());
			messageInfo.setSeverity("Medium");
			requestLineMessageInfo.setMessageInfo(messageInfo);
			listAvailableAppointmentResponse.setRequestLineMessageInfo(requestLineMessageInfo);	
			listAvailableAppointment.setListAvailableAppointmentResponse(listAvailableAppointmentResponse);
			return listAvailableAppointment;
		}	
		
	}


	public AppoinitngValidationResponse validationGetCall(String refNum) {
		String url = "https://appointing-validation-service.cfapps.io/validation/getAppointing";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url).queryParam("refNum", refNum);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);

		return responseEntity.getBody();

	}

	public AppoinitngValidationResponse validationListCall(String startDate) {

		String url = "https://appointing-validation-service.cfapps.io/validation/listAppointment";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url).queryParam("startDate", startDate);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);

		return responseEntity.getBody();

	}

	public AppoinitngValidationResponse validationReserveCall(String AppointmentDate, String AppointmentTimeslot) {

		String url = "http://appointing-validation-service.cfapps.io/validation/reserveAppointing";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url)
				.queryParam("appointmentDate", AppointmentDate).queryParam("appointmentTimeslot", AppointmentTimeslot);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);

		return responseEntity.getBody();

	}

	public String getAvailableEngineerInfo(String referenceId) {

		String engineersUrl = "https://engineerapp.cfapps.io/getAvailableEngineers/" + referenceId;

		ResponseEntity<String> result = restTemplate.getForEntity(engineersUrl, String.class);

		return result.getBody();

	}

	public String post(String referenceId) {

		String engineersUrl = "http://localhost:8080/getAvailableEngineers/" + referenceId;

		ResponseEntity<String> result = restTemplate.getForEntity(engineersUrl, String.class);

		return result.getBody();

	}
	public AppoinitngValidationResponse ReserveCall(String AppointmentDate, String AppointmentTimeslot) {

		String url = "http://localhost:8305/api/reserve";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url)
				.queryParam("date", AppointmentDate).queryParam("slot", AppointmentTimeslot);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);
		return responseEntity.getBody();

	}
	
	public AppoinitngValidationResponse ListCall(String startDate) {

		String url = "http://localhost:8080/validation/listAppointment";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url).queryParam("startDate", startDate);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);

		return responseEntity.getBody();

	}
	
	public AppoinitngValidationResponse GetCall(String refNum) {
		String url = "http://localhost:8305/api/get";
		UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(url).queryParam("app_refId", refNum);
		ResponseEntity<AppoinitngValidationResponse> responseEntity = restTemplate.exchange(uriBuilder.toUriString(),
				HttpMethod.GET, null, AppoinitngValidationResponse.class);
		return responseEntity.getBody();
	}

	

}
