package com.appointing.service;

public class Validation {

	public Validation() {
		// TODO Auto-generated constructor stub
	}
		
		String responseCode;
		String responseMessage;
		public String getResponseCode() {
			return responseCode;
		}
		public void setResponseCode(String responseCode) {
			this.responseCode = responseCode;
		}
		public String getResponseMessage() {
			return responseMessage;
		}
		public void setResponseMessage(String responseMessage) {
			this.responseMessage = responseMessage;
		}	
}
